
console.log("javascript loaded!");

function ListRest() {
  console.log("button clicked!");

  $.getJSON("http://www.omdbapi.com/?s=Home&apikey=94a221d", function(data) {
  console.log(data);
  
  // first set
  var title = data.Search[0].Title;
  $(".title").append(title);
  var type = data.Search[0].Type;
  $(".type").append(type);
  var year = data.Search[0].Year;
  $(".year").append(year);

  // second set
  var title2 = data.Search[1].Title;
  $(".title2").append(title2);
  var type2 = data.Search[1].Type;
  $(".type2").append(type2);
  var year2 = data.Search[1].Year;
  $(".year2").append(year2);

  // third set
  var title3 = data.Search[2].Title;
  $(".title3").append(title3);
  var type3 = data.Search[2].Type;
  $(".type3").append(type3);
  var year3 = data.Search[2].Year;
  $(".year3").append(year3);

  // fourth set
  var title4 = data.Search[3].Title;
  $(".title4").append(title4);
  var type4 = data.Search[3].Type;
  $(".type4").append(type4);
  var year4 = data.Search[3].Year;
  $(".year4").append(year4);

  // fifth set
  var title5 = data.Search[4].Title;
  $(".title5").append(title5);
  var type5 = data.Search[4].Type;
  $(".type5").append(type5);
  var year5 = data.Search[4].Year;
  $(".year5").append(year5);

  })
};

// page 2 js

function moviedetails() {
  console.log("button clicked!");

  $.getJSON("http://www.omdbapi.com/?i=tt0099785&apikey=94a221d", function(data) {
  console.log(data);

  var actors = data.Actors;
  $(".actors").append(actors);
  var awards = data.Awards;
  $(".awards").append(awards);
  var country = data.Country;
  $(".country").append(country);
  var dvd = data.DVD;
  $(".dvd").append(dvd);
  var director = data.Director;
  $(".director").append(director);
  var genre = data.Genre;
  $(".genre").append(genre);

})
};
  // fetch('http://time.jsontest.com/')
  // .then(response => response.json())
  // .then(data => {
  //   console.log(data) // Prints result from `response.json()` in getRequest
  // })
  // .catch(error => console.error(error))

//   var xhr = new XMLHttpRequest
// xhr.open('GET', 'http://time.jsontest.com/');
// xhr.send(null);
//
// xhr.onreadystatechange = function () {
//     console.log("coming back!");
//     var DONE = 4; // readyState 4 means the request is done.
//     var OK = 200; // status 200 is a successful return.
//     if (xhr.readyState === DONE) {
//       if (xhr.status === OK) {
//         console.log(xhr.responseText); // 'This is the returned text.'
//         var response = xhr.responseText;
//         var x = JSON.parse(response);
//         console.log(x["time"]);
//       } else {
//         console.log('Error: ' + xhr.status); // An error occurred during the request.
//       }
//     }
// }
// var output = document.getElementById("date");
// output.innerHTML =

  
